package seleniumSample;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Loginpage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// setup the path
		WebDriverManager.chromedriver().setup(); 
		//launch the browser(chrome)
		 ChromeDriver driver=new ChromeDriver(); 
		 // maximize window
		 driver.manage().window().maximize();
		 //Load the URL
		 driver.get("http://leaftaps.com/opentaps/control/main");
		 //wait
		 driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(30));
		 // Enter username
		 driver.findElement(By.id("username")).sendKeys("demosalesmanager");
		//Enter password
		 driver.findElement(By.id("password")).sendKeys("crmsfa");
		 //Click login button
		 driver.findElement(By.className("decorativeSubmit")).click();

	}

}
