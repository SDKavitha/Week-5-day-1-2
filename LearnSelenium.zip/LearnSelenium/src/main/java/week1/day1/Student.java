package week1.day1;

public class Student {

}
