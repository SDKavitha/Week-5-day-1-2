package week1.day2;

public class PositiveOrNegative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num=35;
		if(num>0)
		{
			System.out.println("The number is positive");
		}
		else if(num<0)
		{
			System.out.println("The number is negative");
		}
		else
		{
			System.out.println("The number is neither positive nor negative");
		}
	}

}
