package week2.day2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HandleDropDown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup(); 
		//launch the browser(chrome)
		 ChromeDriver driver=new ChromeDriver(); 
		 // maximize window
		 driver.manage().window().maximize();
		 //Load the URL
		 driver.get("https://leafground.com/select.xhtml");
		 //wait
		 driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(30));
		//find the dropdown
		 WebElement source = driver.findElement(By.className("ui-selectonemenu"));//ctrl+2+l
		//create obj  for Select 
		 Select sc=new Select(source);
		 sc.selectByIndex(2);
		//sc.selectByValue("");
			// sc.selectByVisibleText("Selenium");
		 					
				
	}

}
