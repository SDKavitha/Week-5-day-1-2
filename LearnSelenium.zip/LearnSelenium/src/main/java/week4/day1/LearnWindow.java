package week4.day1;


import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LearnWindow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leafground.com/window.xhtml");
		driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(30));
		
		//print active window
		String windowHandle = driver.getWindowHandle();
		System.out.println(windowHandle);
		System.out.println(driver.getTitle());
		
		//click and confirm new window open
		driver.findElement(By.xpath("//span[text()='Open']")).click();
		System.out.println(driver.getWindowHandle());
		System.out.println(driver.getTitle());
		
		//how to go second window
		Set<String> windowHandles = driver.getWindowHandles();//we cant switch the window using set 
		System.out.println("How many window opens"+windowHandles.size());//so convert into list
		
		//convert set into list
		List<String> lstname=new ArrayList<String>(windowHandles);
		
		//move the control into second open window
		driver.switchTo().window(lstname.get(1));
		System.out.println(driver.getWindowHandle());
		System.out.println(driver.getTitle());
		//control back to window
		driver.switchTo().window(lstname.get(0));
		System.out.println(driver.getTitle());
		
		//close window
		driver.close();
		driver.quit();//close all window

	}

}
