package week4.day1;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AlertAndFrame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_confirm");
		driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(30));
		
		driver.switchTo().frame("iframeResult");//id//name
		driver.findElement(By.xpath("//button[text()='Try it']")).click();
		Alert fa = driver.switchTo().alert();
		fa.accept();
		String text = driver.findElement(By.xpath("//p[text()='You pressed OK!']")).getText();
		String text1="";
		if(text.contains(text1))
		{
			System.out.println("Element Contains");
		}
		
	}

}
