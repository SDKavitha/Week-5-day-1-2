package week4.day2;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestleafWebTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://testleaf.herokuapp.com/pages/table.html");
		driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(30));

		//Get row count
		List<WebElement> rw = driver.findElements(By.xpath("//table//tr"));
		 System.out.println(rw.size());
		 
		 //Get column count
		 List<WebElement> col = driver.findElements(By.xpath("//table//th"));
		 System.out.println(col.size());
		 
		 //Get Progress value of learn to interact element
		 String text = driver.findElement(By.xpath("//table//tr[3]//td[2]")).getText();
		 System.out.println("Progress value of learn to interact element:"+text);
		 
		 //check the vital task for least completed progress
		 //driver.findElement(By.xpath("//table//tr[4]//td[3]")).click();
		 
		 //Dynamic Handle 
		 for(int i=1;i<rw.size();i++){
		 //Print all the progress value
		 List<WebElement> progress = driver.findElements(By.xpath("//table//tr["+i+"]//td["+i+"]"));
		 
		 for(int j=0;j<=progress.size();j++)
		 {
			 System.out.println(progress.get(j).getText());
		 }
		 
		 }
		 //To print entire table
		 List<WebElement> table = driver.findElements(By.tagName("table"));
		 for(int k=0;k<table.size();k++)
		 {
			 System.out.println(table.get(k).getText());
		 }
		 
	}
	
}
