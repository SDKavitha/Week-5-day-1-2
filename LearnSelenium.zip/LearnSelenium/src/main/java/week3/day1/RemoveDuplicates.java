package week3.day1;

public class RemoveDuplicates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String text = "We learn java basics as part of java sessions in java week1";
		System.out.println(text);
		int count=0;
		String[] str = text.split(" ");
		for(int i=0;i<str.length;i++) {
			for(int j=i+1;j<str.length-1;j++)
			{
			if(str[i].equals(str[j]))
			{
				count=count+1;
			}
			
			}
			if(count>1)
			{
				text=text.replace(str[i], " ");
				break;
			}
		}
		System.out.println("Removed Duplicates:"+text);
	}

}
