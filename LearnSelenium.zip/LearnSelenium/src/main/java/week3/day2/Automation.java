package week3.day2;

public class Automation extends MutilpleLanguage implements TestTool {

	

	public void Java() {
		// TODO Auto-generated method stub
		
	}

	public void Selenium() {
		// TODO Auto-generated method stub
		
	}
	

	@Override
	public void Ruby() {
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Automation auto=new Automation();
     auto.Java();
     auto.Selenium();
     auto.Ruby();
     auto.Python();
	}
}
