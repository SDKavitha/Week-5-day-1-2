package week3.day2;

public abstract class MutilpleLanguage {
	public void Python() {
		
	}
	public abstract void Ruby();

}
