package week3.day2;

public interface Lnguage {
	
	public void Java();

}
