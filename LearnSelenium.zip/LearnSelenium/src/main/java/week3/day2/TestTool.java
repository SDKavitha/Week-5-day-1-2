package week3.day2;

public interface TestTool extends Lnguage{
public void Selenium();
}
