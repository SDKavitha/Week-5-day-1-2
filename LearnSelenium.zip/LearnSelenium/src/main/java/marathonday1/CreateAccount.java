package marathonday1;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeOptions ch=new ChromeOptions();
		ch.addArguments("--disable-notifications");
		ChromeDriver driver=new ChromeDriver(ch);
		
		//ChromeDriver driver=new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://login.salesforce.com/?locale=in");
		driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(30));
		 driver.findElement(By.id("username")).sendKeys("hari.radhakrishnan@qeagle.com");
			//Enter password
			 driver.findElement(By.id("password")).sendKeys("Testleaf$321");
			 //Click login button
			 driver.findElement(By.id("Login")).click();
			 //Click toggle button
			 String title = driver.getTitle();
			System.out.println(title);
			 driver.findElement(By.className("slds-icon-waffle")).click();
			 //System.out.println(driver.getTitle());
			 
			 //Click sales
			 driver.findElement(By.xpath("//p[text()='Sales']")).click();
			 
			//Click accounts
			 WebElement user = driver.findElement(By.xpath("(//span[text()='Accounts'])[1]"));
			 driver.executeScript("arguments[0].click();",user);
		
			 //Click New
			 WebElement user1 = driver.findElement(By.xpath("//div[text()='New']"));
			 driver.executeScript("arguments[0].click();",user1);
			 
			 //Enter account Name
			 driver.findElement(By.xpath("//input[@name='Name']")).sendKeys("Kavitha");
			 
			 //Click Ownership
			 WebElement user2 = driver.findElement(By.xpath("(//button[contains(@class,'slds-combobox__input slds-input_faux slds')])[3]"));
			 driver.executeScript("arguments[0].click();",user2);
			 
			 //Click public
			 WebElement user3 = driver.findElement(By.xpath("(//span[text()='Public'])[1]"));
			 driver.executeScript("arguments[0].click();",user3);
			 
			//Click save
			 WebElement user4 = driver.findElement(By.xpath("//button[@name='SaveEdit']"));
			 driver.executeScript("arguments[0].click();",user4);
			 
			 //verify message
			 
			 
	}

}
